#include <Arduino.h>

class S0Input
{
private:

    static void callbackDispatcher(void *iInstance);
    void pinInterruptHandler();
    void setup();
    void attachInterruptHandlerMethod(pin_size_t iPin, PinStatus iMode);

public:
    S0Input(/* args */);
    ~S0Input();
};
