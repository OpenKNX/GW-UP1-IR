#include "S0Input.h"
         

S0Input::S0Input()
{
}


S0Input::~S0Input()
{
}

void S0Input::initS0(uint8_t pinInt, uint8_t ledPin, uint8_t channel)
{
    _pinInt = pinInt;
    _ledPin = ledPin;
    _channel = channel;

    setup();
}

void S0Input::attachInterruptHandlerMethod(pin_size_t iPin, PinStatus iMode)
{
    attachInterruptParam(iPin, callbackDispatcher, iMode, this);
}

// static callback to call a method of an instance (Pattern)
// this static callback gets a pointer to the instance
void S0Input::callbackDispatcher(void *iInstance)
{
    S0Input *self = static_cast<S0Input *>(iInstance);
    self->pinInterruptHandler();
}

void S0Input::pinInterruptHandler()
{
    _timeStopp = millis();
    _impulseCounted++;
    _newImpulse = true;

#ifdef Serial_Int_output
    SERIAL_DEBUG.print("+");
    SERIAL_DEBUG.println(_channel);
#endif
}

void S0Input::setup()
{
    // hier kannst Du pro Instanz ein attach machen
    attachInterruptHandlerMethod(_pinInt, FALLING);
}
