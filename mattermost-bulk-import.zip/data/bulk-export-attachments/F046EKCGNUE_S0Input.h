#include <Arduino.h>

#define S0_CH1 0
#define S0_CH2 1
#define S0_CH3 2
#define S0_Ch4 3

class S0Input
{
  private:
    bool _newImpulse = false;
    bool _statusLedOn = false;

    uint8_t _pinInt;
    uint8_t _ledPin;
    uint8_t _channel;

    uint16_t _impulseProKwh;
    uint16_t _impulseCounted = 0;
    uint16_t _impulseCounted_ProMin = 0;
    uint16_t _impulseCounted_ProMin_stopp = 0;
    uint16_t _meterValue = 0;

    uint32_t _timeStart = 0;
    uint32_t _timeStopp = 0;
    uint32_t _time_S0_LED_Blink = 0;
    uint32_t _timer_ProMin = 0;

    float _currentConsumption = 0;

    static void callbackDispatcher(void *iInstance);
    void pinInterruptHandler();
    void setup();
    void attachInterruptHandlerMethod(pin_size_t iPin, PinStatus iMode);

  public:
    S0Input();
    ~S0Input();
    void initS0(uint8_t pinInt, uint8_t ledPin, uint8_t channel);
};
